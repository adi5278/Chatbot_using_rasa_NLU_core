## intent:greet
- Hello
- I want your help
- hello bott
- hello

## intent:inform
- weather in [london](location)
- weather
- in [mumbai](location)
- Whats the weather in [Italy](location:italy)?
- show me the weather in [mumbai](location)
- weather in [New York](location)
- [mumbai](location)
- weather in [karad](location)
- [karad](location)
- weather in [mumbai](location)
- weather in [london](location)

## intent:goodbye
- Goodbye
- See ya
- later
- bye bot

## intent:satisfied
- ok
- thanks
- Thanks bot

## synonym:italy
- Italy
